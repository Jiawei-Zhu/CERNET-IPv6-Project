
set -ev

rm -rf ~/.hfc-key-store/*


mkdir -p ~/.hfc-key-store
cp creds/* ~/.hfc-key-store
