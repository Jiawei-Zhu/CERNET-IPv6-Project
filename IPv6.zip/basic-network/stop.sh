
set -ev

docker-compose -f docker-compose.yml stop
